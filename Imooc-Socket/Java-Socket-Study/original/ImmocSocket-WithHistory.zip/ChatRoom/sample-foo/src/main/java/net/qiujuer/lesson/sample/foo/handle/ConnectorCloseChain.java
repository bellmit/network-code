package net.qiujuer.lesson.sample.foo.handle;

import net.qiujuer.library.clink.core.Connector;

/**
 * 关闭链接链式结构
 */
public abstract class ConnectorCloseChain extends ConnectorHandlerChain<Connector> {

}
