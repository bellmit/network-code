package net.qiujuer.lesson.sample.foo.handle;

import net.qiujuer.library.clink.box.StringReceivePacket;

/**
 * 效果字符串包链式封装
 */
public abstract class ConnectorStringPacketChain extends ConnectorHandlerChain<StringReceivePacket> {

}
