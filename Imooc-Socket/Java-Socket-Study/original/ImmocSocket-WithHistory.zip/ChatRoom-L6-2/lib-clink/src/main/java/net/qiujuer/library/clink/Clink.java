package net.qiujuer.library.clink;

public class Clink {
}
